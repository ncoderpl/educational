<?php

/**
 * @package    Grav\Core
 *
 * @copyright  Copyright (c) 2015 - 2026 Trilby Media, LLC. All rights reserved.
 * @license    MIT License; see LICENSE file for details.
 */

// Some standard defines
define("GRAV", true);
define("GRAV_VERSION", "2.2.11");
define("GRAV_SCHEMA", "2.2.4_2026-09-30_0");
define("GRAV_TESTING", false);

// PHP minimum requirement
if (!defined("GRAV_PHP_MIN")) {
    define("GRAV_PHP_MIN", "8.3.0");
}

// Directory separator
if (!defined("DS")) {
    define("DS", "/");
}

// Read a bootstrap variable from wherever the SAPI or Env::load() put it:
// $_SERVER, then $_ENV, then getenv(). Hosts that disable putenv() (Cloudways'
// web SAPI) only ever get a .env into $_SERVER/$_ENV, so a getenv()-only read
// would ignore it. An empty value counts as unset, so it falls through to the
// next source and finally to the default, the same as Setup::envVar().
// Self-contained on purpose: this runs before any class is available.
$grav_env = static function (string $name): ?string {
    foreach ([$_SERVER[$name] ?? null, $_ENV[$name] ?? null, getenv($name)] as $value) {
        if (is_string($value) && $value !== "") {
            return $value;
        }
    }

    return null;
};

// Native .env support: load environment variables from .env file(s) at the Grav
// root (or the GRAV_ENV_PATH location when set, which may live outside the web
// root) before any GRAV_* constant is defined, so a .env can drive the path
// constants below, the environment name read by Setup, and GRAV_CONFIG__*
// overrides. Real server-set environment variables always take precedence.
// The class_exists() guard keeps this file safe to include on its own (e.g. a
// build step reading GRAV_VERSION), where the Composer autoloader isn't present.
if (
    !defined("GRAV_DOTENV_DISABLE") &&
    class_exists(\Grav\Common\Config\Env::class)
) {
    $root = rtrim(
        str_replace(DIRECTORY_SEPARATOR, DS, $grav_env("GRAV_ROOT") ?: getcwd()),
        DS,
    );
    \Grav\Common\Config\Env::load($root ?: DS);
    unset($root);
}

// Absolute path to Grav root. This is where Grav is installed into.
if (!defined("GRAV_ROOT")) {
    $path = rtrim(
        str_replace(DIRECTORY_SEPARATOR, DS, $grav_env("GRAV_ROOT") ?: getcwd()),
        DS,
    );
    define("GRAV_ROOT", $path ?: DS);
}
// Absolute path to Grav webroot. This is the path where your site is located in.
if (!defined("GRAV_WEBROOT")) {
    $path = rtrim($grav_env("GRAV_WEBROOT") ?: GRAV_ROOT, DS);
    define("GRAV_WEBROOT", $path ?: DS);
}
// Relative path to user folder. This path needs to be located under GRAV_WEBROOT.
if (!defined("GRAV_USER_PATH")) {
    $path = rtrim($grav_env("GRAV_USER_PATH") ?: "user", DS);
    define("GRAV_USER_PATH", $path);
}
// Absolute or relative path to system folder. Defaults to GRAV_ROOT/system
// If system folder is outside of webroot, see https://github.com/getgrav/grav/issues/3297#issuecomment-810294972
if (!defined("GRAV_SYSTEM_PATH")) {
    $path = rtrim($grav_env("GRAV_SYSTEM_PATH") ?: "system", DS);
    define("GRAV_SYSTEM_PATH", $path);
}
// Absolute or relative path to cache folder. Defaults to GRAV_ROOT/cache
if (!defined("GRAV_CACHE_PATH")) {
    $path = rtrim($grav_env("GRAV_CACHE_PATH") ?: "cache", DS);
    define("GRAV_CACHE_PATH", $path);
}
// Absolute or relative path to logs folder. Defaults to GRAV_ROOT/logs
if (!defined("GRAV_LOG_PATH")) {
    $path = rtrim($grav_env("GRAV_LOG_PATH") ?: "logs", DS);
    define("GRAV_LOG_PATH", $path);
}
// Absolute or relative path to tmp folder. Defaults to GRAV_ROOT/tmp
if (!defined("GRAV_TMP_PATH")) {
    $path = rtrim($grav_env("GRAV_TMP_PATH") ?: "tmp", DS);
    define("GRAV_TMP_PATH", $path);
}
// Absolute or relative path to backup folder. Defaults to GRAV_ROOT/backup
if (!defined("GRAV_BACKUP_PATH")) {
    $path = rtrim($grav_env("GRAV_BACKUP_PATH") ?: "backup", DS);
    define("GRAV_BACKUP_PATH", $path);
}
unset($path, $grav_env);

// INTERNAL: Do not use!
define("USER_DIR", GRAV_WEBROOT . "/" . GRAV_USER_PATH . "/");
define(
    "CACHE_DIR",
    (!preg_match("`^(/|[a-z]:[\\\/])`ui", GRAV_CACHE_PATH)
        ? GRAV_ROOT . "/"
        : "") .
        GRAV_CACHE_PATH .
        "/",
);

// DEPRECATED: Do not use!
define("CACHE_PATH", GRAV_CACHE_PATH . DS);
define("USER_PATH", GRAV_USER_PATH . DS);
define("ROOT_DIR", GRAV_ROOT . DS);
define("ASSETS_DIR", GRAV_WEBROOT . "/assets/");
define("IMAGES_DIR", GRAV_WEBROOT . "/images/");
define("ACCOUNTS_DIR", USER_DIR . "accounts/");
define("PAGES_DIR", USER_DIR . "pages/");
define("DATA_DIR", USER_DIR . "data/");
define("PLUGINS_DIR", USER_DIR . "plugins/");
define("THEMES_DIR", USER_DIR . "themes/");
define(
    "SYSTEM_DIR",
    (!preg_match("`^(/|[a-z]:[\\\/])`ui", GRAV_SYSTEM_PATH)
        ? GRAV_ROOT . "/"
        : "") .
        GRAV_SYSTEM_PATH .
        "/",
);
define("LIB_DIR", SYSTEM_DIR . "src/");
define("VENDOR_DIR", GRAV_ROOT . "/vendor/");
define(
    "LOG_DIR",
    (!preg_match("`^(/|[a-z]:[\\\/])`ui", GRAV_LOG_PATH)
        ? GRAV_ROOT . "/"
        : "") .
        GRAV_LOG_PATH .
        "/",
);
// END DEPRECATED

// Some extensions
define("CONTENT_EXT", ".md");
define("TEMPLATE_EXT", ".html.twig");
define("TWIG_EXT", ".twig");
define("PLUGIN_EXT", ".php");
define("YAML_EXT", ".yaml");

// Content types
define("RAW_CONTENT", 1);
define("TWIG_CONTENT", 2);
define("TWIG_CONTENT_LIST", 3);
define("TWIG_TEMPLATES", 4);

// Filters
define("GRAV_SANITIZE_STRING", 5001);
